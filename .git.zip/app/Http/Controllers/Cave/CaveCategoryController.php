<?php

namespace App\Http\Controllers\Cave;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CaveForm;
use App\Models\CaveLocation;
use App\Models\CaveCategory;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class CaveCategoryController extends Controller
{
    function __construct()
    {
         $this->middleware('permission:view cave category', ['only' => ['index']]);
         $this->middleware('permission:create cave category', ['only' => ['create','store']]);
         $this->middleware('permission:update cave category', ['only' => ['edit','update']]);
         $this->middleware('permission:delete cave category', ['only' => ['destroy']]);
         ;
    }
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        
         // Validate the request
        $request->validate([
            'keyword' => 'nullable|string|min:1',
        ]);
    
        $keyword = $request->keyword;
    
        // Eloquent query with relationships and search conditions
        $data = CaveCategory::latest('id')
            ->where(function ($query) use ($keyword) {
                $query->where('name', 'LIKE', "%$keyword%")
                      ;
            })
            
            ->paginate(25);
    
        // Return the search results as JSON
        return view('cave.category.index',compact('data'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        
        return view('cave.category.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        request()->validate([
            'name' => 'required',
           
        ]);
        
        
            $data=new CaveCategory();
            $data->name=$request['name'];
            $data->save();
        
        return redirect()->route('vaultcategories.index')
                        ->with('success','Vault Category created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show($id): View
    {
        $data = CaveCategory::find($id);
        return view('cave.category.view',compact('data'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id): View
    {
        $data = CaveCategory::find($id);
        return view('cave.category.edit',compact('data'));
    }

    /**
     * Update the specified resource in storage.
     */
     public function update(Request $request,  $id): RedirectResponse
    {
         $request->validate([
            'name' => [
                'required'
            ]
        ]);
    
        $data = CaveCategory::find($id);
        $data->name=$request['name'];
        $data->save();
    
        return redirect()->back()
                        ->with('success','Vault Category updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id): RedirectResponse
    {
       
        $data = CaveCategory::find($id);
        $data->delete();
    
        return redirect()->route('vaultcategories.index')
                        ->with('success','Vault Category deleted successfully');
    }
}
