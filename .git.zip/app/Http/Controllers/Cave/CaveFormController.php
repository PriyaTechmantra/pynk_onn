<?php

namespace App\Http\Controllers\Cave;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CaveForm;
use App\Models\CaveLocation;
use App\Models\CaveCategory;
use App\Models\CaveDoc;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;
class CaveFormController extends Controller
{
    function __construct()
    {
         $this->middleware('permission:view cave form|take out list|vault take out list csv download', ['only' => ['index']]);
         $this->middleware('permission:create cave form', ['only' => ['create','store']]);
         $this->middleware('permission:update cave form', ['only' => ['edit','update']]);
         $this->middleware('permission:delete cave form', ['only' => ['destroy']]);
         ;
    }
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        
         // Validate the request
        $request->validate([
            'keyword' => 'nullable|string|min:1',
        ]);
    
        $keyword = $request->keyword;
    
        // Eloquent query with relationships and search conditions
        $data = CaveForm::with(['takeOut.user', 'location', 'category'])
            ->where(function ($query) use ($keyword) {
                $query->where('client_name', 'LIKE', "%$keyword%")
                      ->orWhere('remarks', 'LIKE', "%$keyword%");
            })
            ->orWhereHas('location', function ($query) use ($keyword) {
                $query->where('location', 'LIKE', "%$keyword%");
            })
            ->orWhereHas('category', function ($query) use ($keyword) {
                $query->where('name', 'LIKE', "%$keyword%");
            })
            ->latest('id')->paginate(25);
    
        // Return the search results as JSON
        return view('cave.form.index',compact('data'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        $location=CaveLocation::all();
        $category=CaveCategory::all();
        return view('cave.form.create',compact('location','request','category'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        request()->validate([
            'location_id' => 'required',
           
            //'category_id' => 'required',
            //'client_name' => 'required',
        ]);
        $uploadedPaths = [];
         $path = public_path('uploads/cave');
         function generateUniqueAlphaNumeric($length = 10) {
            $random_string = '';
            for ($i = 0; $i < $length; $i++) {
                $number = random_int(0, 36);
                $character = base_convert($number, 10, 36);
                $random_string .= $character;
            }
            return $random_string;
        }
            $data=new CaveForm();
            $data->location_id=$request['location_id'];
            //$data->category_id=$request['category_id'];
            $data->client_name=$request['client_name']??'';
           // $data->remarks=$request['remarks']??'';
            $data->room=$request['room']??'';
            $data->name=$request['name']??'';
            $data->sub_location=$request['sub_location']??'';
            $data->description=$request['description']??'';
            $data->qrcode=strtoupper(generateUniqueAlphaNumeric(10));
            if (!file_exists($path)) {
                            mkdir($path, 0777, true); // Create the directory if it doesn't exist
                        }

                if ($request->hasFile('document')) {
                    foreach ($request->file('document') as $file) {
                        // Generate a unique filename
                        $fileName = $file->getClientOriginalName();
            
                        // Move the file to the 'public/uploads/cave' directory
                        $file->move($path, $fileName);
            
                        // Save the relative path for database storage
                        $uploadedPaths[] = 'uploads/cave/' . $fileName;
                        $commaSeparatedPaths = implode(',', $uploadedPaths);
                        $data->document=$commaSeparatedPaths;
                    }
                }

                // Convert paths to a comma-separated string
                
                
               $data->save();
        
        return redirect()->route('vaults.index')
                        ->with('success','Vault created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show($id): View
    {
        $data = CaveForm::find($id);
        return view('cave.form.view',compact('data'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id): View
    {
        $data = CaveForm::find($id);
        $location=CaveLocation::all();
        $category=CaveCategory::all();
        return view('cave.form.edit',compact('data','location','category'));
    }

    /**
     * Update the specified resource in storage.
     */
public function update(Request $request, $id): RedirectResponse
{
    // Validate the input
    $request->validate([
        'location_id' => [
            'required'
        ]
    ]);

    $data = CaveForm::findOrFail($id); // Find the record or throw a 404 error if not found

    // Update fields
    $data->location_id = $request->input('location_id');
    $data->client_name = $request->input('client_name', '');
    $data->room = $request->input('room', '');
    $data->name = $request->input('name', '');
    $data->sub_location = $request->input('sub_location', '');
    $data->description = $request->input('description', '');

    // File upload path
    $uploadDir = 'uploads/cave'; // Define the relative directory
    $path = public_path($uploadDir);

    // Create the directory if it doesn't exist
    if (!file_exists($path)) {
        mkdir($path, 0777, true);
    }

    // Handle existing document paths
    $existingPaths = $data->document ?? '';
    $existingPathsArray = !empty($existingPaths) ? explode(',', $existingPaths) : [];

    // Process uploaded files
    $uploadedPaths = [];
    if ($request->hasFile('document')) {
        foreach ($request->file('document') as $file) {
            // Generate the file name
            $fileName = $file->getClientOriginalName();

            // Move the file to the upload directory
            $file->move($path, $fileName);

            // Save the relative file path
            $uploadedPaths[] = $uploadDir . '/' . $fileName;
        }
    }

    // Merge and update document paths
    $updatedPaths = array_merge($existingPathsArray, $uploadedPaths);
    $data->document = implode(',', $updatedPaths);

    // Save the updated record
    $data->save();

    // Redirect with a success message
    return redirect()->route('vaults.index')
        ->with('success', 'Vault updated successfully');
}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id): RedirectResponse
    {
        $data = CaveForm::find($id);
        $data->delete();
    
        return redirect()->route('vaults.index')
                        ->with('success','Vault deleted successfully');
    }
    
    
    
    public function takeoutList(Request $request,$id)
    {
       $issueDateFrom = $request->input('issue_date_from');
       $issueDateTo = $request->input('issue_date_to');
       $query = CaveDoc::where('cave_form_id',$id)->where('status',1);
       if (!empty($issueDateFrom) && !empty($issueDateTo)) {
            $query->whereBetween('cave_docs.created_at', [
                Carbon::parse($issueDateFrom)->startOfDay(),
                Carbon::parse($issueDateTo)->endOfDay()
            ]);
        } elseif (!empty($issueDateFrom)) {
            $query->whereDate('cave_docs.created_at', '>=', Carbon::parse($issueDateFrom)->startOfDay());
        } elseif (!empty($issueDateTo)) {
            $query->whereDate('cave_docs.created_at', '<=', Carbon::parse($issueDateTo)->endOfDay());
        }
        // Get the paginated results
        $data = $query->paginate(25);
        $form=CaveForm::where('id',$id)->first();
       return view('cave.form.issue-detail',compact('data','form','request'));
       
       
    }
    
    
    
     public function takeoutListcsvExport(Request $request,$id)
	{
	    $bookData=CaveForm::where('id',$id)->first();
	   $issueDateFrom = $request->input('issue_date_from');
       $issueDateTo = $request->input('issue_date_to');
       $query = CaveDoc::where('cave_form_id',$id)->where('status',1);
       if (!empty($issueDateFrom) && !empty($issueDateTo)) {
            $query->whereBetween('cave_docs.created_at', [
                Carbon::parse($issueDateFrom)->startOfDay(),
                Carbon::parse($issueDateTo)->endOfDay()
            ]);
        } elseif (!empty($issueDateFrom)) {
            $query->whereDate('cave_docs.created_at', '>=', Carbon::parse($issueDateFrom)->startOfDay());
        } elseif (!empty($issueDateTo)) {
            $query->whereDate('cave_docs.created_at', '<=', Carbon::parse($issueDateTo)->endOfDay());
        }
        // Get the paginated results
        $data = $query->cursor();
        $book = $data->all();
        if (count($book) > 0) {
            $delimiter = ","; 
            $filename = "take-out-lists of-".$bookData->client_name."(".$bookData->client_name.")".".csv"; 

            // Create a file pointer 
            $f = fopen('php://memory', 'w'); 

            // Set column headers 
            // $fields = array('SR', 'QRCODE TITLE','CODE','DISTRIBUTOR','ASE','STORE NAME','STORE MOBILE','STORE EMAIL','STORE STATE','STORE ADDRESS','POINTS','DATE'); 
            $fields = array('SR', 'Member Name','Member Mobile','Member Email','Take out date','Returned date'); 
            fputcsv($f, $fields, $delimiter); 

            $count = 1;

            foreach($book as $row) {
                
				 $returnDate=\App\Models\CaveDoc::where('cave_form_id',$row->id)->where('user_id',$row->user->id)->where('status',0)->first();     
                if(!empty($returnDate))
                {
                    $date=date('j M Y', strtotime($returnDate->created_at));
                }else{
                    $date='';
                }
                $lineData = array(
                    $count,
					$row->user->name ?? 'NA',
                    $row->user->mobile  ?? 'NA',
					$row->user->email ?? 'NA',
					date('j M Y', strtotime($row->created_at)) ?? 'NA',
					$date ?? 'NA'
                );

                fputcsv($f, $lineData, $delimiter);

                $count++;
            }

            // Move back to beginning of file
            fseek($f, 0);

            // Set headers to download file rather than displayed
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="' . $filename . '";');

            //output all remaining data on a file pointer
            fpassthru($f);
        }
	}
}
