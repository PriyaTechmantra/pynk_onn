<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Book;
use App\Models\Bookshelve;
use App\Models\Bookmark;
use App\Models\LmsNotification;
use App\Models\IssueBook;
use App\Models\BookTransfer;
use Illuminate\Support\Facades\Validator;

class BookController extends Controller
{
    public function index(Request $request)
    {
        $books = Book::with(['office','bookshelve','category'])->get();
        if ($books) {
             return response()->json(['status'=>true,'message' => 'List of book','data' => $books ], 200);
        }else {
            return response()->json([
                'status' => false,
                'message' => 'Book list not found'
            ], 404);
        }
    }

   public function activeBookList(Request $request, $id)
    {
        $pageNo =$request->pageNo;
    // Fetch books with related data and where status is active (status = 1)
                if(!$pageNo){
                    $page=1;
                }else{
                    $page=$pageNo;
				 }
                    $limit=10;
                    $offset=($page-1)*$limit;
    $books = Book::where('status', 1)->with(['office', 'bookshelve', 'category','issueBooks.user'])->limit($limit)->offset($offset)->get();
    $bookCount=Book::where('status', 1)->count();
    $count= (int) ceil($bookCount / $limit);

    // Check if books are found
    if ($books->count() > 0) {
        foreach ($books as $item) {
            $isWishlist = false;

            // Check if user ID is provided
            if (!empty($id)) {
                $check_user_wishlist = Bookmark::where('user_id', $id)->where('book_id', $item->id)->first();

                // If the book is in the user's wishlist, set $isWishlist to true
                if (!empty($check_user_wishlist)) {
                    $isWishlist = true;
                }
            }

            // Add the wishlist status to the book object
            $item->isWishlist = $isWishlist;
        }

        // Return the list of books with a success message
        return response()->json(['status' => true, 'message' => 'List of books', 'data' => $books,
				'count'=>$count], 200);
    } else {
        // Return a not found message if no books are available
        return response()->json([
            'status' => false,
            'message' => 'Book list not found'
        ], 404);
    }
}

    public function bookWithIssuedBook(Request $request)
    {
        $books = Book::with(['office','bookshelve','category','issuebook.user'])->get();
        if ($books) {
            return response()->json(['status'=>true,'message' => 'List of book with issue details','data' => $books, ], 200);
        }else {
            return response()->json([
                'status' => false,
                'message' => 'Book list not found'
            ], 404);
        }
    }
    public function bookDetails(Request $request)
    {
  
        try {
            $book = Book::with(['office','bookshelve','category'])->findOrFail($request->id);
            if ($book) {
                
            return response()->json([
                'status'=>true,
                'message' => 'Detail of book',
                'data' => $book
            ], 200);
            }else {
                return response()->json([
                    'status' => false,
                    'message' => 'Details not found'
                ], 404);
            }
            
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while fetching the book details.',
                'error' => $e->getMessage()
            ], 500);
        }
    }
   

  
    public function search(Request $request,$id)
    {
        try {
            $keyword = $request->input('keyword'); 
            $cat = $request->input('category_id'); 
             $pageNo =$request->pageNo;
                // Fetch books with related data and where status is active (status = 1)
                if(!$pageNo){
                    $page=1;
                }else{
                    $page=$pageNo;
				 }
                    $limit=10;
                    $offset=($page-1)*$limit;
            $books = Book::where('status', 1);

            if ($keyword) {
                $books->where(function ($query) use ($keyword) {
                    $query->where('title', 'LIKE', "%{$keyword}%")
                        ->orWhere('publisher', 'LIKE', "%{$keyword}%")
                        ->orWhere('author', 'LIKE', "%{$keyword}%")
                        ->orWhere('year', 'LIKE', "%{$keyword}%")
                        ->orWhere('edition', 'LIKE', "%{$keyword}%")
                        ->orWhere('uid', 'LIKE', "%{$keyword}%")
                        ->orWhereHas('office', function ($query) use ($keyword) {
                            $query->where('address', 'LIKE', "%{$keyword}%");
                        });
                });

                
            }
            if ($cat) {
                $books->where(function ($query) use ($cat) {
                    $query->where('category_id', '=', $cat);
                        
                });

                
            }

            //$books = $books->with('category', 'office', 'bookshelve', 'issueBooks.user')->limit($limit)->offset($offset)->get();
            $books = $books->with('category', 'office', 'bookshelve', 'issueBooks.user')->latest('id')->get();
            $bookCount=Book::where('status', 1);

            if ($keyword) {
                $bookCount->where(function ($query) use ($keyword) {
                    $query->where('title', 'LIKE', "%{$keyword}%")
                        ->orWhere('publisher', 'LIKE', "%{$keyword}%")
                        ->orWhere('author', 'LIKE', "%{$keyword}%")
                        ->orWhere('year', 'LIKE', "%{$keyword}%")
                        ->orWhere('edition', 'LIKE', "%{$keyword}%")
                        ->orWhere('uid', 'LIKE', "%{$keyword}%")
                        ->orWhereHas('office', function ($query) use ($keyword) {
                            $query->where('address', 'LIKE', "%{$keyword}%");
                        });
                });

                
            };
            if ($cat) {
                $bookCount->where(function ($query) use ($cat) {
                    $query->where('category_id', '=', $cat);
                        
                });

                
            };
            $bookCount=$bookCount->count();
            $count= (int) ceil($bookCount / $limit);
            if ($books->count() > 0) {
                foreach ($books as $item) {
                    $isWishlist = false;
                    $isRequestlist= false;
                    // Check if user ID is provided
                    if (!empty($id)) {
                        $check_user_wishlist = Bookmark::where('from_user_id', $id)->first();
                        
                        // If the book is in the user's wishlist, set $isWishlist to true
                        if (!empty($check_user_wishlist)) {
                            $isWishlist = true;
                        }
                        $check_request_user=LmsNotification::where('message','request book')->where('sender_id', $id)->where('book_id', $item->id)->first();
                        $issueList=IssueBook::where('user_id',$id)->where('book_id', $item->id)->first();
                        $transferList=BookTransfer::where('to_user_id',$id)->where('book_id', $item->id)->first();
                        if (!empty($check_request_user) && empty($issueList) && empty($transferList)) {
                            $isRequestlist = true;
                        }
                        
                    }
        
                    // Add the wishlist status to the book object
                    $item->isWishlist = $isWishlist;
                    $item->isRequestlist = $isRequestlist;
                }

                    // Return the list of books with a success message
                    return response()->json(['status' => true, 'message' => 'List of books', 'data' => $books,
				'count'=>$count], 200);
            } else {
                return response()->json([
                    'status' => false,
                    'message' => 'No data found'
                ], 404);
            }
        } catch (\Exception $e) {
           
            return response()->json([
                'message' => 'An error occurred during the search.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    


    public function searchDetailsByQrCode(Request $request)
    {
        try{
            $qrcode = $request->input('qrcode');

            $book = Book::where('qrcode', $qrcode)->with(['category','office','bookshelve'])
                ->first();
            if ($book) {
                return response()->json([
                    'status'=>true,
                    'message' => 'Details of book by Qr-Code',
                    'data' =>$book
                ], 200);
            }else {
                return response()->json([
                    'status' => false,
                    'message' => 'Details not found'
                ], 404);
            }
        } catch (\Exception $e) {
            DB::rollBack(); 
            Log::error('Book transfer error: ' . $e->getMessage());
            return response()->json([
                'message' => 'An error occurred during the book transfer.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    public function CategoryWiseBookList(Request $request)
    {
                $pageNo =$request->pageNo;
        // Fetch books with related data and where status is active (status = 1)
                if(!$pageNo){
                    $page=1;
                }else{
                    $page=$pageNo;
				 }
                    $limit=10;
                    $offset=($page-1)*$limit;
        $books = Book::where('category_id', $request->category_id)->where('status', 1)->with(['office', 'bookshelve','issueBooks.user'])->limit($limit)->offset($offset)->get();
        $bookCount=Book::where('category_id', $request->category_id)->where('status', 1)->count();
        $count= (int) ceil($bookCount / $limit);
        if ($books->count() > 0) {
                foreach ($books as $item) {
                    $isWishlist = false;
        
                    // Check if user ID is provided
                    if (!empty($request->user_id)) {
                        $check_user_wishlist = Bookmark::where('user_id', $request->user_id)->where('book_id', $item->id)->first();
        
                        // If the book is in the user's wishlist, set $isWishlist to true
                        if (!empty($check_user_wishlist)) {
                            $isWishlist = true;
                        }
                    }
        
                    // Add the wishlist status to the book object
                    $item->isWishlist = $isWishlist;
                }

                    // Return the list of books with a success message
                    return response()->json(['status' => true, 'message' => 'List of books', 'data' => $books,
				'count'=>$count], 200);
        }else {
            return response()->json([
                'status' => false,
                'message' => 'Book not found'
            ], 404);
        }
    }

    public function showBooksByBookShelveQRCode(Request $request)
    {
        $bookshelve = Bookshelve::where('qrcode', $request->qrcode)->first();

        if (!$bookshelve) {
            return response()->json(['message' => 'Bookshelf not found','status'=>false], 404);
        }

        $books = $bookshelve->books()->with(['office', 'category'])->get();
        if ($books) {
            return response()->json([
                'books' => $books->map(function ($book) {
                    return [
                        'status'=>true,
                        'message' => 'Book list by shelve QR-code wise',
                        'data'=> $book
                    ];
                })
            ],200);
        }else {
            return response()->json([
                'status' => false,
                'message' => 'Book not found'
                
            ], 404);
        }
    }

   
    public function showBooksByBookShelve(Request $request)
    {
        $bookshelve = Bookshelve::where('number', $request->number)->first();

        if (!$bookshelve) {
            return response()->json(['message' => 'Bookshelf not found','status'=>false], 404);
        }

        $books = $bookshelve->books()->get();
        if ($books) {
        return response()->json([
            'status'=>true,
            'message' => 'Book list by shelve number wise', 
            
            'books' => $books->map(function ($book) {
                return [
                    'data'=> $book,
                ];
            })
        ],200);
        }else {
            return response()->json([
                'status' => false,
                'message' => 'Book not found'
               
            ], 404);
        }

    }


}
 