<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CaveForm;
use App\Models\CaveLocation;
use App\Models\CaveDoc;
use DB;
use Illuminate\Support\Facades\Validator;
class CaveController extends Controller
{
    public function index(Request $request,$id)
    {
        $data = CaveForm::join('cave_docs', 'cave_docs.cave_form_id', '=', 'cave_forms.id')
        ->where('cave_docs.user_id', $id)
        ->where('cave_docs.status', 1) // Only consider records with status = 1
        ->whereNotIn('cave_docs.cave_form_id', function ($query) use ($id) {
            $query->select('cave_form_id')
                ->from('cave_docs')
                ->where('user_id', $id)
                ->where('status', 0); // Exclude records that have status = 0 for the same cave_form_id
        })
        ->with(['location', 'category'])
        ->get();
        if ($data) {
             return response()->json(['status'=>true,'message' => 'List of items','data' => $data ], 200);
        }else {
            return response()->json([
                'status' => false,
                'message' => 'Not found'
            ], 404);
        }
    }
    
    /*public function search(Request $request)
    {
         $request->validate([
            'keyword' => 'required|string|min:1',
        ]);

        $keyword = $request->keyword;

        // Search query with joins
        $results = DB::table('cave_forms')
            ->join('cave_locations', 'cave_locations.id', '=', 'cave_forms.location_id')
            ->join('cave_categories', 'cave_categories.id', '=', 'cave_forms.category_id')
            ->where(function ($query) use ($keyword) {
                $query->where('cave_forms.client_name', 'LIKE', "%$keyword%")
                      ->orWhere('cave_forms.remarks', 'LIKE', "%$keyword%")
                      ->orWhere('cave_locations.location', 'LIKE', "%$keyword%")
                      ->orWhere('cave_categories.name', 'LIKE', "%$keyword%");
            })
            ->select('cave_forms.id','cave_forms.client_name as client_name', 'cave_forms.remarks', 'cave_locations.location', 'cave_categories.name')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $results,
        ]);
    
    }*/
    
    // public function search(Request $request)
    // {
    //     // Validate the request
    //     $request->validate([
    //         'keyword' => 'required|string|min:1',
    //     ]);
    
    //     $keyword = $request->keyword;
    
    //     // Eloquent query with relationships and search conditions
    //     $results = CaveForm::with(['takeOut.user', 'location', 'category'])
    //         ->where(function ($query) use ($keyword) {
    //             $query->where('client_name', 'LIKE', "%$keyword%")
    //                   ->orWhere('remarks', 'LIKE', "%$keyword%");
    //         })
    //         ->orWhereHas('location', function ($query) use ($keyword) {
    //             $query->where('location', 'LIKE', "%$keyword%");
    //         })
    //         ->orWhereHas('category', function ($query) use ($keyword) {
    //             $query->where('name', 'LIKE', "%$keyword%");
    //         })
    //         ->get();
    
    //     // Return the search results as JSON
    //     return response()->json([
    //         'success' => true,
    //         'data' => $results,
    //     ]);
    // }
    
    
public function search(Request $request)
{
    // Validate the request
    $request->validate([
        'keyword' => 'required|string|min:1',
        'user_id' => 'required|integer', // Ensure user_id is provided
    ]);

    $keyword = $request->keyword;
    $userId = $request->user_id;

    // Eloquent query with relationships and search conditions
    $results = CaveForm::with(['takeOut.user', 'location', 'category'])
        ->where(function ($query) use ($keyword) {
            $query->where('client_name', 'LIKE', "%$keyword%")
                  ->orWhere('remarks', 'LIKE', "%$keyword%");
        })
        ->orWhereHas('location', function ($query) use ($keyword) {
            $query->where('location', 'LIKE', "%$keyword%");
        })
        ->orWhereHas('category', function ($query) use ($keyword) {
            $query->where('name', 'LIKE', "%$keyword%");
        })
        ->get();

    // Add a status message for 'takeOut' to indicate document status
    $results->transform(function ($item) use ($userId) {
        // Filter takeOut records by user_id and cave_form_id
        $takeOutRecords = CaveDoc::where('cave_form_id', $item->id)
        ->where('user_id', $userId)
        ->get();

        $status1Exists = $takeOutRecords->where('status', 1)->isNotEmpty();
        $status0Exists = $takeOutRecords->where('status', 0)->isNotEmpty();
    
        if ($status1Exists && $status0Exists) {
            $item->doc_status = 'Returned';
        } elseif ($status1Exists) {
            $item->doc_status = 'Not Returned';
        } else {
            $item->doc_status = 'No Records';
        }
    
        return $item;
    });

    // Return the search results as JSON
    return response()->json([
        'success' => true,
        'data' => $results,
    ]);
}
    
    
    public function detail(Request $request,$id)
    {
        $data=CaveForm::where('id',$id)->with('takeOut.user','location','category')->get();
        if ($data) {
             return response()->json(['status'=>true,'message' => 'List of items','data' => $data ], 200);
        }else {
            return response()->json([
                'status' => false,
                'message' => 'Not found'
            ], 404);
        }
    }
    public function store(Request $request)
    {
         $validator = Validator::make($request->all(), [
            'user_id' => 'required',
           // 'cave_form_id' => 'required',
             'qrcode' => 'required|string', 
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => false, 'error' => $validator->errors()], 400);
        }else{
            $qrcode=CaveForm::where('qrcode',$request->qrcode)->first();
            //barcode exist check
            if(!$qrcode){
                return response()->json(['error'=>false, 'resp'=>'QR code is invalid']);
            }else{
                $data=CaveDoc::where('user_id',$request->user_id)->where('cave_form_id',$qrcode->id)->where('status',1)->first();
                
                
                if (!$data) {
                    $data = CaveDoc::create([
                        'user_id' => $request->user_id,
                        'cave_form_id' => $qrcode->id,
                        'status' => 1,
                    ]);
                     return response()->json(['status'=>true,'message' => 'data submitted successfully','data' => $data ], 200);
                }else {
                    return response()->json([
                        'status' => false,
                        'message' => 'Already added'
                    ], 404);
                }
            }
        }
    }
    
    
    public function received(Request $request)
    {
         $validator = Validator::make($request->all(), [
            'user_id' => 'required',
            'qrcode' => 'required|string', 
            'cave_form_id' => 'nullable',
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => false, 'error' => $validator->errors()], 400);
        }else{
            $caveQr = CaveLocation::where('qrcode', $request->qrcode)
            ->first();
    
            if (!$caveQr) {
                return response()->json(['message' => 'No locations found for the provided QR code.','status' => false], 404);
            }
            $qrcode=CaveForm::where('id',$request->cave_form_id)->first();
            //barcode exist check
            if(!$qrcode){
                return response()->json(['error'=>false, 'resp'=>'No vault found on the provided location.']);
            }else{
                $data=CaveDoc::where('user_id',$request->user_id)->where('cave_form_id',$request->cave_form_id)->where('status',0)->first();
                
                
                if (!$data) {
                    $data = CaveDoc::create([
                        'user_id' => $request->user_id,
                        'cave_form_id' => $qrcode->id,
                        'status' => 0,
                    ]);
                     return response()->json(['status'=>true,'message' => 'data submitted successfully','data' => $data ], 200);
                }else {
                    return response()->json([
                        'status' => false,
                        'message' => 'Already returned'
                    ], 404);
                }
            }
        }
    }
}
