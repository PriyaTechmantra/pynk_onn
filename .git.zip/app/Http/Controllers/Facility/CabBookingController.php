<?php

namespace App\Http\Controllers\Facility;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CabBooking;
use Illuminate\View\View; 
use Carbon\Carbon;
class CabBookingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {
         $this->middleware('permission:view cab booking', ['only' => ['index']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
  public function index(Request $request): View
{
    // Capture inputs
    $keyword = $request->input('keyword');
    $issueDateFrom = $request->input('date_from');
    $issueDateTo = $request->input('date_to');
    
    // Start the query
    $query = CabBooking::latest('id');
    
    // Apply the keyword search conditions
    if (!empty($keyword)) {
        $query->where(function ($query) use ($keyword) {
            $query->where('matter_code', 'LIKE', "%$keyword%")
                  ->orWhere('from_location', 'LIKE', "%$keyword%")
                  ->orWhere('to_location', 'LIKE', "%$keyword%")
                  ->orWhere('pickup_date', 'LIKE', "%$keyword%")
                  ->orWhere('pickup_time', 'LIKE', "%$keyword%")
                  ->orWhere('traveller', 'LIKE', "%$keyword%")
                  ->orWhere('bill_to', 'LIKE', "%$keyword%")
                  ->orWhereHas('user', function ($query) use ($keyword) {
                      $query->where('name', 'LIKE', "%$keyword%");
                  });
        });
    }

    // Apply the bill_to filter based on the keyword input (company, client, etc.)
    if (!empty($keyword)) {
        if (stripos($keyword, 'company') !== false) {
            $query->where('bill_to', 1); // For 'company', filter where bill_to = 1
        } elseif (stripos($keyword, 'client') !== false) {
            $query->where('bill_to', 2); // For 'client', filter where bill_to = 2
        } elseif (stripos($keyword, 'matter expenses') !== false) {
            $query->where('bill_to', 3); // For 'matter expenses', filter where bill_to = 3
        }
    }

    // Apply date range filter if both are provided
    if (!empty($issueDateFrom) && !empty($issueDateTo)) {
        $query->whereBetween('pickup_date', [
            Carbon::parse($issueDateFrom)->startOfDay(),
            Carbon::parse($issueDateTo)->endOfDay()
        ]);
    } 
    // Apply date filter if only 'date_from' is provided
    elseif (!empty($issueDateFrom)) {
        $query->whereDate('pickup_date', '>=', Carbon::parse($issueDateFrom)->startOfDay());
    } 
    // Apply date filter if only 'date_to' is provided
    elseif (!empty($issueDateTo)) {
        $query->whereDate('pickup_date', '<=', Carbon::parse($issueDateTo)->endOfDay());
    }

    // Execute the query and paginate results
    $data = $query->paginate(25);
     
    // Return the view with data
    return view('facility.cab-booking.index', compact('data', 'request'))
        ->with('i', (request()->input('page', 1) - 1) * 5);
}

}
