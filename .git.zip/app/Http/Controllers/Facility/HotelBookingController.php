<?php

namespace App\Http\Controllers\Facility;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\HotelBooking;
use Illuminate\View\View;
class HotelBookingController extends Controller
{
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {
         $this->middleware('permission:view hotel booking', ['only' => ['index']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(): View
    {
        $data = HotelBooking::latest()->paginate(25);
        return view('facility.hotel-booking.index',compact('data'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }
}
