<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CaveDoc extends Model
{
    use HasFactory;
    protected $fillable = [
        'cave_form_id',
        'user_id',
        'status',  // Add this line
        // ... other fillable fields
    ];
    public function user()
    {
         return $this->belongsTo(User::class);
    }
    
}
