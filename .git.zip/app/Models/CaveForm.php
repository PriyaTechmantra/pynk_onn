<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CaveForm extends Model
{
    use HasFactory;
    
    public function takeOut()
    {
    return $this->hasMany(CaveDoc::class)->where('status', 1)
                ;
    }
    public function location()
    {
         return $this->belongsTo(CaveLocation::class);
    }
    
    public function category()
    {
         return $this->belongsTo(CaveCategory::class);
    }
    
    
}
