@extends('layouts.app')

@section('content')


<div class="container mt-5">
        <div class="row">
            <div class="col-md-12">

                @if ($errors->any())
                <ul class="alert alert-warning">
                    @foreach ($errors->all() as $error)
                        <li>{{$error}}</li>
                    @endforeach
                </ul>
                @endif

                <div class="card">
                    <div class="card-header">
                        <h4>Vault Details
                            <a href="{{ url('vaults') }}" class="btn btn-danger float-end">Back</a>
                           
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="">
                                 
                                <tr>
                                    <td class="text-muted"> Location: </td>
                                    <td>{{ $data->location->location ??''}}</td>
                                </tr>
                                
                               
                                <tr>
                                    <td class="text-muted">Category : </td>
                                    <td>{{$data->category->name}}</td>
                                </tr>
                                <tr>
                                    <td class="text-muted">Client : </td>
                                    <td>{{ $data->client_name ??''}}</td>
                                </tr>
                                <tr>
                                    <td class="text-muted">Remarks : </td>
                                    <td>{{ $data->remarks ??''}}</td>
                                </tr>
                               
                                <tr>
                                    <td class="text-muted">Created At: </td>
                                    <td>{{ date('j M Y h:m A', strtotime($data->created_at)) }}</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
               
@endsection


@section('script')

@endsection