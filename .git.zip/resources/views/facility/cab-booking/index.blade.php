@extends('layouts.app')

@section('content')


<div class="container mt-2">
        <div class="row">
            <div class="col-md-12">

                @if (session('status'))
                    <div class="alert alert-success">{{ session('status') }}</div>
                @endif

                <div class="card data-card mt-3">
                    <div class="card-header">
                        <h4 class="d-flex">Cab Booking Request
                            @can('cab booking list csv export')
                            <a href="{{ url('books/export/csv',['office_id'=>$request->office_id,'bookshelves_id'=>$request->bookshelves_id,'category_id'=>$request->category_id,'keyword'=>$request->keyword]) }}" class="btn btn-sm btn-cta ms-auto" data-bs-toggle="tooltip" title="Export data in CSV">
                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                                CSV
                            </a>
                            @endcan
                        </h4>
                         <div class="search__filter mb-0">
                                    <div class="row">
                                        <div class="col-12">
                                            <p class="text-muted mt-1 mb-0">Showing {{$data->count()}} out of {{$data->total()}} Entries</p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        
                                        <div class="col-12">
                                            <form action="">
                                                <div class="row">
                                                    <div class="col">
                                                        <input type="date" name="date_from" id="term" class="form-control form-control-sm"  value="{{app('request')->input('date_from')}}">
                                                    </div>
                                                     <div class="col">
                                                        <input type="date" name="date_to" id="term" class="form-control form-control-sm"  value="{{app('request')->input('date_to')}}">
                                                    </div>
                                                   
                                                    
                                                    <div class="col">
                                                        <input type="search" name="keyword" id="term" class="form-control form-control-sm" placeholder="Search by keyword." value="{{app('request')->input('keyword')}}" autocomplete="off">
                                                    </div>
                                                </div>
                                                <div class="row mt-2">
                                                    <div class="col-12 text-end">
                                                        <!--<div class="btn-group books_btn_group">-->
                                                            <button type="submit" class="btn btn-sm btn-cta">
                                                                Filter
                                                            </button>
                            
                                                            <a href="{{ url()->current() }}" class="btn btn-sm btn-cta" data-bs-toggle="tooltip" title="Clear Filter">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                                            </a>
                                                        <!--</div>-->
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        
                                    </div>
                                </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                            <thead>
                                <tr>
                                    <th class="index-col">#</th>
                                    <th>Member</th>
                                    <th>From</th>
                                    <th>To</th>
                                    <th>Pickup Date & Time</th>
                                    <th>Traveller</th>
                                    <th>Bill to</th>
                                    <th>Matter Code</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($data as $index=> $item)
                                <tr>
                                    <td class="index-col">{{ $index+1 }}</td>
                                    <td><a href="{{ url('members/'.$item->user->id) }}">{{ $item->user->name }}</a></td>
                                    <td>{{ $item->from_location }}</td>
                                    <td>{{ $item->to_location }}</td>
                                    <td>{{ date('j F Y', strtotime($item->pickup_date)) . ' ' . date('g:i A', strtotime($item->pickup_time)) }}</td>
                                    <td>{{ $item->traveller }}</td>
                                    <td>{{ $item->bill_to == 1 ? 'Company' : ($item->bill_to == 2 ? 'Client' : 'Matter Expenses') }}</td>
                                    <td>{{ $item->matter_code }}</td>
                                    
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                        </div>
                         {{ $data->appends($_GET)->render() }}
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection