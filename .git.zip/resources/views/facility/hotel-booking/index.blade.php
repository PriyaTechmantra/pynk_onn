@extends('layouts.app')

@section('content')


<div class="container mt-2">
        <div class="row">
            <div class="col-md-12">

                @if (session('status'))
                    <div class="alert alert-success">{{ session('status') }}</div>
                @endif

                <div class="card data-card mt-3">
                    <div class="card-header">
                        <h4>Hotel Booking Request
                            
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                            <thead>
                                <tr>
                                    <th class="index-col">#</th>
                                    <th>Member</th>
                                    <th>Property</th>
                                    <th>Check In</th>
                                    <th>Check Out</th>
                                    <th>Guest Type</th>
                                    <th>Guest Number</th>
                                    <th>Bill to</th>
                                    <th>Matter Code</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($data as $index=> $item)
                                <tr>
                                    <td class="index-col">{{ $index+1 }}</td>
                                    <td style="white-space:nowrap;"><a href="{{ url('members/'.$item->user->id) }}">{{ $item->user->name }}</a></td>
                                    <td>{{ $item->property->name }}</td>
                                    <td style="white-space:nowrap;">{{ $item->checkin_date }}</td>
                                    <td style="white-space:nowrap;">{{ $item->checkout_date }}</td>
                                    <td>{{ $item->guest_type }}</td>
                                    <td>{{ $item->guest_number }}</td>
                                    <td>{{ $item->bill_to == 1 ? 'Company' : ($item->bill_to == 2 ? 'Client' : 'Matter Expenses') }}</td>
                                    <td>{{ $item->matter_code }}</td>
                                    
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                        </div>
                         {{ $data->appends($_GET)->render() }}
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection