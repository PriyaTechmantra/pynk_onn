@extends('layouts.app')

@section('content')


<div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                @php
                  $permission=DB::table('user_permission_categories')->where('user_id',$user->id)->pluck('name');
                @endphp
                @if ($errors->any())
                <ul class="alert alert-warning">
                    @foreach ($errors->all() as $error)
                        <li>{{$error}}</li>
                    @endforeach
                </ul>
                @endif

                <div class="card data-card">
                    <div class="card-header">
                        <h4 class="d-flex">Member Detail
                            <a href="{{ url('members') }}" class="btn btn-cta ms-auto">Back</a>
                           
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-xl-3 col-lg-2 col-12"></div>
                            <div class="col-xl-6 col-lg-8 col-12">
                                <div class="table-responsive">
                                    <table class="table">
                                         <div class="user-info">
                                            <tr>
                                                <td class="text-muted">Name: </td>
                                                <td>{{$user->name}}</td>
                                            </tr>
                                         </div>
                                        <tr>
                                            <td class="text-muted">Email: </td>
                                            <td>{{ $user->email ??''}}</td>
                                        </tr>
                                        
                                        <tr>
                                            <td class="text-muted">Mobile :  </td>
                                            <td>{{ $user->mobile }}</td>
                                        </tr>
                                         <tr>
                                            <td class="text-muted">Designation :  </td>
                                            <td>{{ $user->designation }}</td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">Type :  </td>
                                            <td>{{ $user->type }}</td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">App Permission : </td>
                                            <td>{{ $permission->implode(', ') }}</td>
                                        </tr>
                                       
                                        <tr>
                                            <td class="text-muted">Created At: </td>
                                            <td>{{ date('j M Y h:m A', strtotime($user->created_at)) }}</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-2 col-12"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
               
@endsection


@section('script')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- printThis Plugin -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/printThis/1.15.0/printThis.min.js"></script>

@endsection