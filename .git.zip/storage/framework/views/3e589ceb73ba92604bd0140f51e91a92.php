<?php $__env->startSection('content'); ?>


<div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <?php
                  $permission=DB::table('user_permission_categories')->where('user_id',$user->id)->pluck('name');
                ?>
                <?php if($errors->any()): ?>
                <ul class="alert alert-warning">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>

                <div class="card data-card">
                    <div class="card-header">
                        <h4 class="d-flex">Member Detail
                            <a href="<?php echo e(url('members')); ?>" class="btn btn-cta ms-auto">Back</a>
                           
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-xl-3 col-lg-2 col-12"></div>
                            <div class="col-xl-6 col-lg-8 col-12">
                                <div class="table-responsive">
                                    <table class="table">
                                         <div class="user-info">
                                            <tr>
                                                <td class="text-muted">Name: </td>
                                                <td><?php echo e($user->name); ?></td>
                                            </tr>
                                         </div>
                                        <tr>
                                            <td class="text-muted">Email: </td>
                                            <td><?php echo e($user->email ??''); ?></td>
                                        </tr>
                                        
                                        <tr>
                                            <td class="text-muted">Mobile :  </td>
                                            <td><?php echo e($user->mobile); ?></td>
                                        </tr>
                                         <tr>
                                            <td class="text-muted">Designation :  </td>
                                            <td><?php echo e($user->designation); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">Type :  </td>
                                            <td><?php echo e($user->type); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">App Permission : </td>
                                            <td><?php echo e($permission->implode(', ')); ?></td>
                                        </tr>
                                       
                                        <tr>
                                            <td class="text-muted">Created At: </td>
                                            <td><?php echo e(date('j M Y h:m A', strtotime($user->created_at))); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-2 col-12"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
               
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- printThis Plugin -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/printThis/1.15.0/printThis.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/vangu1yt/public_html/dev/fnm_lms/resources/views/lms/member/view.blade.php ENDPATH**/ ?>