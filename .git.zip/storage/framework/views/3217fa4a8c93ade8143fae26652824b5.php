<?php $__env->startSection('content'); ?>


<div class="container mt-2">
        <div class="row">
            <div class="col-md-12">

                <?php if(session('status')): ?>
                    <div class="alert alert-success"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <div class="card data-card mt-3">
                    <div class="card-header">
                        <h4 class="d-flex">
                            Take out Details of <?php echo e($form->client_name); ?>(<?php echo e($form->remarks); ?>)
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vault take out list csv download')): ?>
                            <a href="<?php echo e(url('vaults/takeout/list/export/csv/'.$form->id)); ?>" class="btn btn-sm btn-cta ms-auto" data-bs-toggle="tooltip" title="Export data in CSV">
                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                                CSV
                            </a>
                            <?php endif; ?>
                        </h4>
                                <div class="search__filter mb-0">
                                    <div class="row">
                                        <div class="col-12">
                                            <p class="text-muted mt-1 mb-0">Showing <?php echo e($data->count()); ?> out of <?php echo e($data->total()); ?> Entries</p>
                                        </div>
                                    </div>
                                        <div class="row">
                                        
                                            <div class="col-md-12 text-end">
                                                <form class="row align-items-end" action="">
                                                    <div class="col">
                                                        <input type="date" name="issue_date_from" id="term" class="form-control form-control-sm"  value="<?php echo e(app('request')->input('issue_date_from')); ?>">
                                                    </div>
                                                     <div class="col">
                                                        <input type="date" name="issue_date_to" id="term" class="form-control form-control-sm"  value="<?php echo e(app('request')->input('issue_date_to')); ?>">
                                                    </div>
                                                    <div class="col text-end">
                                                        <!--<div class="btn-group">-->
                                                            <button type="submit" class="btn btn-cta btn-sm">
                                                                Filter
                                                            </button>
                        
                                                            <a href="<?php echo e(url()->current()); ?>" class="btn btn-sm btn-cta" data-bs-toggle="tooltip" title="Clear Filter">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                                            </a>
                                                            
                                                        <!--</div>-->
                                                    </div>
                                                </form>
                                            </div>
                                           
                                        </div>
                                    
                                </div>
                                
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                            <thead>
                                <tr>
                                    <th class="sl_no index-col">#</th>
                                    <th class="bookshelf">Member Name</th>
                                    <th class="bookshelf">Member Mobile</th>
                                    <th class="bookshelf">Member Email</th>
                                    <th class="bookshelf">Take out date</th>
                                    <th class="bookshelf">Returned date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $returnDate=\App\Models\CaveDoc::where('cave_form_id',$item->id)->where('user_id',$item->user->id)->where('status',0)->first();   
                                ?>
                                <tr>
                                    <td class="index-col"><?php echo e($index+1); ?></td>
                                    <td><?php echo e($item->user->name ??''); ?></td>
                                    <td><?php echo e($item->user->mobile ??''); ?></td>
                                    <td><?php echo e($item->user->email); ?></td>
                                    <td><?php echo e(date('j M Y', strtotime($item->created_at))); ?></td>
                                    <?php if(!empty($returnDate)): ?>
                                    <td><?php echo e(date('j M Y', strtotime($returnDate->created_at))); ?></td>
                                    <?php else: ?>
                                    <td></td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        </div>
                        <?php echo $data->render(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>



<div class="modal fade" id="csvModal" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                Bulk Upload
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="post" action="<?php echo e(url('books/upload/csv')); ?>" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                    <input type="file" name="file" class="form-control" accept=".csv">
                    <br>
                    <a href="<?php echo e(asset('backend/csv/sample-book.csv')); ?>">Download Sample CSV</a>
                    <br>
                    <button type="submit" class="btn btn-danger mt-3" id="csvImportBtn">Import <i class="fas fa-upload"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script>
    $('select[name="office_id"]').on('change', (event) => {
        var value = $('select[name="office_id"]').val();
        OfficeChange(value);
    });
    <?php if(request()->input('office_id')): ?>
        OfficeChange(<?php echo e(request()->input('office_id')); ?>)
    <?php endif; ?>

    function OfficeChange(value) {
        $.ajax({
            url: '<?php echo e(url("/")); ?>/bookshelves/list/officewise/'+value,
            method: 'GET',
            success: function(result) {
                var content = '';
                var slectTag = 'select[name="bookshelves_id"]';
                var displayCollection =  "All";

                content += '<option value="" selected>'+displayCollection+'</option>';
                $.each(result.data, (key, value) => {
                    let selected = ``;
                    <?php if(request()->input('bookshelves_id')): ?>
                        if(<?php echo e(request()->input('bookshelves_id')); ?> == value.id) {selected = 'selected';}
                    <?php endif; ?>
                    content += '<option value="'+value.id+'"'; content+=selected; content += '>'+value.number+'</option>';
                });
                $(slectTag).html(content).attr('disabled', false);
            }
        });
    }
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/vangu1yt/public_html/dev/fnm_lms/resources/views/cave/form/issue-detail.blade.php ENDPATH**/ ?>