<?php $__env->startSection('content'); ?>


<div class="container mt-2">
        <div class="row">
            <div class="col-md-12">

                <?php if(session('status')): ?>
                    <div class="alert alert-success"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <div class="card data-card mt-3">
                    <div class="card-header">
                        <h4>Flight Booking Request
                            
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                            <thead>
                                <tr>
                                    <th class="index-col">#</th>
                                    <th>Member</th>
                                    <th>From</th>
                                    <th>To</th>
                                    <th style="white-space:nowrap;">Departure Date & Time</th>
                                    <th style="white-space:nowrap;">Preffered Arrival Time</th>
                                    <th>Traveller</th>
                                    <th>Bill to</th>
                                    <th>Matter Code</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="index-col"><?php echo e($index+1); ?></td>
                                    <td style="white-space:nowrap;"><a href="<?php echo e(url('members/'.$item->user->id)); ?>"><?php echo e($item->user->name); ?></a></td>
                                    <td><?php echo e($item->from); ?></td>
                                    <td><?php echo e($item->to); ?></td>
                                    <td><?php echo e($item->departure_date); ?></td>
                                    <td><?php echo e($item->arrival_time); ?></td>
                                    <td><?php echo e($item->traveller); ?></td>
                                    <td><?php echo e($item->bill_to == 1 ? 'Company' : ($item->bill_to == 2 ? 'Client' : 'Matter Expenses')); ?></td>
                                    <td><?php echo e($item->matter_code); ?></td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        </div>
                         <?php echo e($data->appends($_GET)->render()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/vangu1yt/public_html/dev/fnm_lms/resources/views/facility/flight-booking/index.blade.php ENDPATH**/ ?>