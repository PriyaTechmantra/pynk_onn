<?php $__env->startSection('content'); ?>


<div class="container mt-5">
        <div class="row">
            <div class="col-md-12">

                <?php if($errors->any()): ?>
                <ul class="alert alert-warning">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header">
                        <h4>Vault Details
                            <a href="<?php echo e(url('vaults')); ?>" class="btn btn-danger float-end">Back</a>
                           
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="">
                                 
                                <tr>
                                    <td class="text-muted"> Location: </td>
                                    <td><?php echo e($data->location->location ??''); ?></td>
                                </tr>
                                
                               
                                <tr>
                                    <td class="text-muted">Category : </td>
                                    <td><?php echo e($data->category->name); ?></td>
                                </tr>
                                <tr>
                                    <td class="text-muted">Client : </td>
                                    <td><?php echo e($data->client_name ??''); ?></td>
                                </tr>
                                <tr>
                                    <td class="text-muted">Remarks : </td>
                                    <td><?php echo e($data->remarks ??''); ?></td>
                                </tr>
                               
                                <tr>
                                    <td class="text-muted">Created At: </td>
                                    <td><?php echo e(date('j M Y h:m A', strtotime($data->created_at))); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
               
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/vangu1yt/public_html/dev/fnm_lms/resources/views/cave/category/view.blade.php ENDPATH**/ ?>