<?php $__env->startSection('content'); ?>


<div class="container mt-5">
        <div class="row">
            <div class="col-md-12">

                <?php if($errors->any()): ?>
                <ul class="alert alert-warning">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>

                <div class="card data-card">
                    <div class="card-header">
                        <h4 class="d-flex">Create Books
                            <a href="<?php echo e(url('books')); ?>" class="btn btn-cta ms-auto">Back</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-xl-3 col-lg-2 col-12"></div>
                            <div class="col-xl-6 col-lg-8 col-12">
                                <form action="<?php echo e(url('books')); ?>" method="POST" class="data-form">
                                    <?php echo csrf_field(); ?>
        
                                    <div class="mb-3">
                                        <label for="">Office</label>
                                        <select class="form-select form-select-sm" aria-label="Default select example" name="office_id" id="office_id">
                                            <option value="" selected disabled>Select Office</option>
                                            <?php $__currentLoopData = $office; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($cat->id); ?>" <?php echo e(request()->input('office_id') == $cat->id ? 'selected' : ''); ?>> <?php echo e($cat->name); ?>(<?php echo e($cat->address); ?>)</option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Bookshelve</label>
                                        <select class="form-select form-select-sm" aria-label="Default select example" name="bookshelves_id" id="bookshelves">
                                            <option value="" selected disabled>Select Bookshelve</option>
                                            
                                            <option value="<?php echo e($request->bookshelves_id); ?>">Select Office  first</option>
                                                                
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Category</label>
                                       <select class="form-select form-select-sm" aria-label="Default select example" name="category_id" id="category_id">
                                        <option value="" selected disabled>Select Category</option>
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>" <?php echo e(request()->input('category_id') == $cat->id ? 'selected' : ''); ?>> <?php echo e($cat->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="">Title</label>
                                        <input type="text" name="title" class="form-control" placeholder="Enter Title"/>
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Author</label>
                                        <input type="text" name="author" class="form-control" placeholder="Enter Author"/>
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Publisher</label>
                                        <input type="text" name="publisher" class="form-control" placeholder="Enter Publisher"/>
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Edition</label>
                                        <input type="text" name="edition" class="form-control" placeholder="Enter Edition"/>
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Pages</label>
                                        <input type="text" name="page" class="form-control" placeholder="Enter Pages"/>
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Year</label>
                                        <input type="text" name="year" value="" placeholder="Enter Year" class="form-control" />
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Quantity</label>
                                        <input type="text" name="quantity" class="form-control" placeholder="Enter Quantity"/>
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Book No</label>
                                        <input type="text" name="book_no" class="form-control" placeholder="Enter Book no"/>
                                    </div>
                                    <div class="text-end mb-3">
                                        <button type="submit" class="btn btn-submit">Save</button>
                                    </div>
                                </form>
                            </div>
                            <div class="col-xl-3 col-lg-2 col-12"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script>
    $('select[name="office_id"]').on('change', (event) => {
        var value = $('select[name="office_id"]').val();
        OfficeChange(value);
    });
    <?php if(request()->input('office_id')): ?>
        OfficeChange(<?php echo e(request()->input('office_id')); ?>)
    <?php endif; ?>

    function OfficeChange(value) {
        $.ajax({
            url: '<?php echo e(url("/")); ?>/bookshelves/list/officewise/'+value,
            method: 'GET',
            success: function(result) {
                var content = '';
                var slectTag = 'select[name="bookshelves_id"]';
                var displayCollection =  "All";

                content += '<option value="" selected>'+displayCollection+'</option>';
                $.each(result.data, (key, value) => {
                    let selected = ``;
                    <?php if(request()->input('bookshelves_id')): ?>
                        if(<?php echo e(request()->input('bookshelves_id')); ?> == value.id) {selected = 'selected';}
                    <?php endif; ?>
                    content += '<option value="'+value.id+'"'; content+=selected; content += '>'+value.number+'</option>';
                });
                $(slectTag).html(content).attr('disabled', false);
            }
        });
    }
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/vangu1yt/public_html/dev/fnm_lms/resources/views/lms/book/create.blade.php ENDPATH**/ ?>