<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('backend/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/css/style.css')); ?>" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo e(asset('backend/images/logo.png')); ?>" type="image/x-icon">
    <title>Fox & Mandal</title>
  </head>
  <body>
    <main class="login">
      
      <div class="login__right">
        <div class="login__block">
          <div class="logo__block">
            <img src="<?php echo e(asset('backend/images/logo.png')); ?>">
          </div>

          <?php if(Session::get('success')): ?><div class="alert alert-success"><?php echo e(Session::get('success')); ?></div><?php endif; ?>
          <?php if(Session::get('failure')): ?><div class="alert alert-danger"><?php echo e(Session::get('failure')); ?></div><?php endif; ?>

          <form method="POST" action="<?php echo e(route('login')); ?>">
          <?php echo csrf_field(); ?>
            <div class="form-floating mb-3">
              <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" id="floatingInput" placeholder="name@example.com">
              <label for="floatingInput">Email address</label>
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="small text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="form-floating mb-3">
              <input type="password" class="form-control" name="password" id="floatingPassword" placeholder="Password">
              <label for="floatingPassword">Password</label>
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="small text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            

            <div class="d-grid">
              <button type="submit" class="btn btn-lg btn-primary">Login</button>
            </div>
          </form>

          
        </div>
      </div>
    </main>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="<?php echo e(asset('backend/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php /**PATH /home4/vangu1yt/public_html/dev/fnm_lms/resources/views/auth/login.blade.php ENDPATH**/ ?>